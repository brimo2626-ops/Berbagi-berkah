<?php

$telegram_id = "5608160241";
$id_bot      = "8016183333:AAFFucwW9B1MLSi_MqWwJaOQNOB32MW697Q";
?>
